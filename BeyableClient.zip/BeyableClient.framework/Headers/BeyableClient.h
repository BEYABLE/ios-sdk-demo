//
//  BeyableClient.h
//  BeyableClient
//
//  Created by Ouamassi Brahim on 13/02/2024.
//

#import <Foundation/Foundation.h>

//! Project version number for BeyableClient.
FOUNDATION_EXPORT double BeyableClientVersionNumber;

//! Project version string for BeyableClient.
FOUNDATION_EXPORT const unsigned char BeyableClientVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BeyableClient/PublicHeader.h>


